-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11c101.p.ssafy.io    Database: arbaguette
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract` (
  `contract_id` int NOT NULL AUTO_INCREMENT,
  `boss_sign` varchar(255) DEFAULT NULL,
  `crew_sign` varchar(255) DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `salary` int NOT NULL,
  `salary_date` int NOT NULL,
  `start_date` date DEFAULT NULL,
  `tax` enum('INCOME','INSU','NONE') DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `crew_id` int DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`contract_id`),
  UNIQUE KEY `UKe4q2eywxu8v9uqdkavi325a5d` (`crew_id`),
  KEY `FKm8jvj0jm2ihmy0fvrupie0ndk` (`company_id`),
  CONSTRAINT `FKa6owskl0rs4dsejtkn63783lu` FOREIGN KEY (`crew_id`) REFERENCES `crew` (`crew_id`),
  CONSTRAINT `FKm8jvj0jm2ihmy0fvrupie0ndk` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
INSERT INTO `contract` VALUES (1,'123','123','2024-09-30',10000,15,'2024-10-02','INCOME',1,1,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/contract_61.pdf'),(14,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/2024092417073529441838100300','https://arbaguette.s3.ap-northeast-2.amazonaws.com/2024092417081829484122305000','2024-12-31',10000,15,'2024-09-24','INCOME',2,8,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/contract_61.pdf'),(18,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/2024092613163115584810740300','https://arbaguette.s3.ap-northeast-2.amazonaws.com/2024092613195415787052225400','2024-12-31',5000,15,'2024-10-10','INSU',3,5,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/contract_61.pdf'),(19,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/2024092616033925612605035000','https://arbaguette.s3.ap-northeast-2.amazonaws.com/2024092616034725620405684600','2024-11-30',10000,15,'2024-09-26','INSU',2,6,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/contract_61.pdf'),(22,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/202409271711391587586325778921','https://arbaguette.s3.ap-northeast-2.amazonaws.com/202409271712251587631518712975','2024-11-30',10000,15,'2024-06-26','INSU',2,2,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/contract_61.pdf'),(33,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/202410012347581956965098214812','https://arbaguette.s3.ap-northeast-2.amazonaws.com/202410041727572193364280152491','2024-11-01',9860,15,'2024-10-01','INCOME',1,4,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/contract_61.pdf'),(34,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/202410031722332106640397488977','https://arbaguette.s3.ap-northeast-2.amazonaws.com/202410041551502187596740883716','2024-12-31',10000,15,'2024-10-07','INCOME',2,3,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/contract_61.pdf'),(56,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/2024100815214823086104763700','https://arbaguette.s3.ap-northeast-2.amazonaws.com/2024100815215023088594711000','2024-12-31',10000,15,'2024-10-09','INSU',1,7,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/contract_56.pdf'),(59,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/202410091522242617831151821900','https://arbaguette.s3.ap-northeast-2.amazonaws.com/202410091523212617887589228044','2024-12-31',10000,15,'2024-10-09','INCOME',2,11,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/contract_59.pdf'),(60,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/202410091541372618983523851292','https://arbaguette.s3.ap-northeast-2.amazonaws.com/202410091542362619042436143046','2024-12-31',10000,15,'2024-10-09','INCOME',2,12,'https://arbaguette.s3.ap-northeast-2.amazonaws.com/contract_60.pdf');
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 21:08:09
