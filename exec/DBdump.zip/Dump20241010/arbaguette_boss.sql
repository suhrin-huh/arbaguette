-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11c101.p.ssafy.io    Database: arbaguette
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `boss`
--

DROP TABLE IF EXISTS `boss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `boss` (
  `boss_id` int NOT NULL AUTO_INCREMENT,
  `account` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `user_key` varchar(255) DEFAULT NULL,
  `account_password` varchar(255) DEFAULT NULL,
  `bluetooth_token` varchar(255) DEFAULT NULL,
  `expo_push_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`boss_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boss`
--

LOCK TABLES `boss` WRITE;
/*!40000 ALTER TABLE `boss` DISABLE KEYS */;
INSERT INTO `boss` VALUES (1,'0016421491726717','kwesbdhfd@naver.com','아르바게트','$2a$10$fNZxcWqHz.l50kN3C3277uKOORS5dl95bFvlFrXiSzpuYnyfDk/Ga','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%8C%E1%85%B5%E1%86%B8%E1%84%80%E1%85%A6%E1%84%89%E1%85%A1%E1%84%8C%E1%85%A1%E1%86%BC.jpeg','010-1234-5678','46ae36c1-9354-4d5a-8b3e-801fcff1fb60','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,NULL),(3,'0013109073877694','dkssudgktp234@test.com','김싸피','$2a$10$XwbyhpidExT8eEjRu8sPAe97ah7W.S4a1gPqmZDgOkjW2pS5BVJJS','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%8C%E1%85%B5%E1%86%B8%E1%84%80%E1%85%A6%E1%84%89%E1%85%A1%E1%84%8C%E1%85%A1%E1%86%BC.jpeg','010-0000-0000','eac1776f-8f8d-48bd-9d2f-525ebc08736d','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,NULL),(4,'0014999285832829','sonboss@naver.com','사장님','$2a$10$cZlKdMbCqwZFYoN4yk3Fgudzsbp.72t6Otg1iQbdzVSDlXgHAFYHi','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%8C%E1%85%B5%E1%86%B8%E1%84%80%E1%85%A6%E1%84%89%E1%85%A1%E1%84%8C%E1%85%A1%E1%86%BC.jpeg','010-1234-5678','bf5a7f60-5812-40b8-8026-7c50242fd964','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,NULL),(8,'0015715466468013','kangcw0107@gmail.com','강창우','$2a$10$5ySHiRkqvx9LLbYyqDWAE.c7bgEFaL2HdTJ9F5fPRqClZQwzdpjHm','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%8C%E1%85%B5%E1%86%B8%E1%84%80%E1%85%A6%E1%84%89%E1%85%A1%E1%84%8C%E1%85%A1%E1%86%BC.jpeg','010-1234-5678','dd580395-452d-420a-8cf5-11e9e6f0ad6e','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,NULL),(9,'0012381589893158','asdf@naver.com','황민채','$2a$10$iCtwCZqiMxdiyOXdFyX4nuOGxszLFZ8Bp3C/dhQdVtZ9g7NMaaHQ6','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%8C%E1%85%B5%E1%86%B8%E1%84%80%E1%85%A6%E1%84%89%E1%85%A1%E1%84%8C%E1%85%A1%E1%86%BC.jpeg','010-2505-0000','d06bb61d-cbfa-4daf-b10f-d6efe8cb29a4','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,NULL),(11,'0019181114080822','kcw0107@naver.com','강창우','$2a$10$ATlwNiCWY5oRKS7XLtm0ouciWOoGpi8ZzX7Co/lP3mmmwKWkrjsw6','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%8C%E1%85%B5%E1%86%B8%E1%84%80%E1%85%A6%E1%84%89%E1%85%A1%E1%84%8C%E1%85%A1%E1%86%BC.jpeg','010-1111-1111','fb46b44a-763b-449b-9306-537cccfb9064','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,NULL),(12,'0018881639209565','kimjiwon12@naver.com','김지원','$2a$10$G1b7R2J6ScncTxyN/mt/hOzNzwOvXam8igsOVBMkbokGo7.aSwAEy','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%8C%E1%85%B5%E1%86%B8%E1%84%80%E1%85%A6%E1%84%89%E1%85%A1%E1%84%8C%E1%85%A1%E1%86%BC.jpeg','010-6384-5678','a15b7f25-4186-4162-a378-b77c25d409b3','$2a$10$y0TPqW7gHrnhWVqnSWNF3OjvYAtyWueY4CMeIzvxrKXqc2DdUILl6',NULL,NULL);
/*!40000 ALTER TABLE `boss` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 21:08:09
