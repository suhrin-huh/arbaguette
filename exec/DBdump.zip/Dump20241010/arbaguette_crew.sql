-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11c101.p.ssafy.io    Database: arbaguette
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `crew`
--

DROP TABLE IF EXISTS `crew`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crew` (
  `crew_id` int NOT NULL AUTO_INCREMENT,
  `account` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `user_key` varchar(255) DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `status` enum('SIGNED','UNREGISTERED','UNSIGNED') DEFAULT NULL,
  `crew_status` enum('SIGNED','UNREGISTERED','UNSIGNED') DEFAULT NULL,
  `account_password` varchar(255) DEFAULT NULL,
  `bluetooth_token` varchar(255) DEFAULT NULL,
  `expo_push_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`crew_id`),
  KEY `FK4d7c9r26m80i3uy3t9cbxge87` (`company_id`),
  CONSTRAINT `FK4d7c9r26m80i3uy3t9cbxge87` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crew`
--

LOCK TABLES `crew` WRITE;
/*!40000 ALTER TABLE `crew` DISABLE KEYS */;
INSERT INTO `crew` VALUES (1,'0015279282645588','arbaguette9887@naver.com','아르바이트생','$2a$10$LKejOvQqLTBvuUyxp5yPVuMGBzeqdHPjXSIiEAgjDcX7fAMobnjau','https://arbaguette.s3.ap-northeast-2.amazonaws.com/kwt5kctetxuhulzo1qst.png','010-1234-5678','8595be6d-5dcf-4db9-9bd6-00424eb4baf4',1,NULL,'SIGNED','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,NULL),(2,'0012731234766633','soncrew@naver.com','손다인','$2a$10$/Z5SeqbIaDmxnWwP0pqpdO10uG/GsSqa9OmeinUPk0n9ZoGf6RrTO','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%8C%E1%85%B5%E1%86%BC%E1%84%8C%E1%85%B5%E1%86%BC%E1%84%8B%E1%85%B5.jpeg','010-5250-9716','16461d4e-1dca-4e84-887c-8a1f7f220153',2,NULL,'SIGNED','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,''),(3,'0017062650879518','kimcrew@naver.com','김지원','$2a$10$HpTK6buyebHALwo4r8Aja.f8cwB00Hf8c7zDd3NyktSTPgOTUWq2m','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%91%E1%85%B5%E1%86%BC%E1%84%91%E1%85%B5%E1%86%BC%E1%84%8B%E1%85%B5.jpeg','010-3342-3922','5305c1ed-6eea-44d7-a373-7db62d378afb',2,NULL,'SIGNED','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,NULL),(4,'0014119226656525','kangcrew@naver.com','강알바','$2a$10$j0NYvV.bl2awxsUyCTRE2.aatImRh1yAeDrwMb0x51HeEjBCORcyi','https://arbaguette.s3.ap-northeast-2.amazonaws.com/kwt5kctetxuhulzo1qst.png','010-5037-1111','3aaf00f5-4b79-42c0-8f6e-e6103964604b',1,NULL,'SIGNED','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,NULL),(5,'0012051106947538','dkssud123@dkssud.com','김가가','$2a$10$auMsV5qnvjpM1M0wEz/Zxe0p6YeynmgkU43hdk.chiXwSUqVrRalS','https://arbaguette.s3.ap-northeast-2.amazonaws.com/kwt5kctetxuhulzo1qst.png','010-0000-0000','21164254-55b5-4620-8343-cfe85506edcd',3,NULL,'SIGNED','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,''),(6,'0012041806929532','dkssud@naver.comm','김보현','$2a$10$OfVKCG6xfCAQdULARx2kNOGQtDzED0aAPq92Et2eJbQ5KBv5oa27y','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%84%E1%85%AE%E1%86%BC%E1%84%8B%E1%85%B5.jpeg','010-1245-7894','fb4190b6-a4ed-44e8-b035-d0e79b4b0f0f',2,NULL,'SIGNED','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK','abcd',''),(7,'0012678482639641','parkcrew@naver.com','박알바','$2a$10$a88rE.wBQO4wI91MC84bPOXiehyPE39JRh5n91CjEab6r7OFrXkKu','https://arbaguette.s3.ap-northeast-2.amazonaws.com/kwt5kctetxuhulzo1qst.png','010-4830-1111','6c7f358a-bc9a-4d02-828b-d904faf3e178',1,NULL,'SIGNED','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,NULL),(8,'0013871086686805','hwangcrew@naver.com','황민채','$2a$10$zH8qIydsWRxCHBAkrem87eqPEoB6ZOhy1kKVB6HbDlUm6D.VMZYBC','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%80%E1%85%A9%E1%84%85%E1%85%A2.jpg','010-2509-1111','e901d065-ef6d-4646-b68c-34da8d466317',2,NULL,'SIGNED','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,''),(9,'0012314058591847','hello@hello.hello','김알바','$2a$10$CYlgkjzqYVbG08CK593tF.DSywUXM.B7o.N60S0W1e6vXs./xYdG6','https://arbaguette.s3.ap-northeast-2.amazonaws.com/kwt5kctetxuhulzo1qst.png','010-9511-9511','4c081cd9-b0b9-4517-94bb-c05d1cead242',NULL,NULL,'UNREGISTERED','$2a$10$pA2IMFUADBZyEu1HD0i11eEU7Yu1mTwmG.N8jQJO1tGz4ubSGmSzK',NULL,NULL),(10,'0014411141286672','jicrew2@naver.com','지크루','$2a$10$LcG5rW6GTP4gon7CVqUeneHDOW5jMmIjb3Dw0R/Uckjru0QrA/lJ6','https://arbaguette.s3.ap-northeast-2.amazonaws.com/kwt5kctetxuhulzo1qst.png','010-5250-2222','2c9dc078-e2f4-4b5a-9aa3-84fa514749bb',NULL,NULL,'UNREGISTERED','$2a$10$cVCYeKFeLsiQmESnNuJXFOBAGsZJ43gJlwAJd84XJqWL8YuRmw.T.',NULL,NULL),(11,'0014495004953644','dacrew@naver.com','박지훈','$2a$10$0p5hM7ZqMG4aWGXBsOXA0u9LYn7f1ioFiTs7KShKxBFXRBipwW85a','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%91%E1%85%B3%E1%86%AF%E1%84%85%E1%85%A1%E1%86%BC%E1%84%8F%E1%85%B3%E1%84%90%E1%85%A9%E1%86%AB.jpg','010-5250-3333','d571ed20-5181-4821-a990-a9b58a09e5a7',2,NULL,'SIGNED','$2a$10$.AbJIqoH.WKKn6rLZI9RUuwWSjZTB7f804fubTFAjeeYH6X2cTMZy',NULL,''),(12,'0013410910584936','dacrew2@naver.com','강창우','$2a$10$QVEhuVYq7V9uzAlFaK/SVeW0Kblqad.L8n3AwTkAtACNCB9Uff7ge','https://arbaguette.s3.ap-northeast-2.amazonaws.com/%E1%84%87%E1%85%A5%E1%84%80%E1%85%A5%E1%84%89%E1%85%B3%E1%84%91%E1%85%A5%E1%86%AB%E1%84%8C%E1%85%B5%E1%84%87%E1%85%A1%E1%86%B8.jpeg','010-5250-4444','0e40d4e5-386a-40b1-9dbb-45356f50feb3',2,NULL,'SIGNED','$2a$10$Y/rEDvtdo2wqxNqwNRY8W.N57hnEHqzjiotXt1KRPAYo2BB4oaFdW',NULL,''),(14,'0019993652243821','you@you.you','유','$2a$10$GicIo2oKkfjfY6/X5WAKQOgiUIZguUIXysuNNzN.0Iz9ii89kIo6i','https://arbaguette.s3.ap-northeast-2.amazonaws.com/202410052207252296531842123943','010-9876-9876','4949ca95-f2e0-4910-96b3-449d5bd74711',NULL,NULL,'UNREGISTERED','$2a$10$idRvYxXU6NGAFfPn7bzs7enYpxa9ZTgdv0mFPPJAAiTM4yMJMTLZy',NULL,NULL),(16,'0013143959970680','arba@ssafy.com','김싸피','$2a$10$XYFQsGn2wtCjWfYoPky9vOStkXZAh6LWgll1EV2pMDftYskiMMdFO','https://arbaguette.s3.ap-northeast-2.amazonaws.com/202410102010532721539487959223','010-9999-9999','39485b00-75e3-4325-9ee8-aec950a20dd7',NULL,NULL,'UNREGISTERED','$2a$10$zVIm2huJcjlpAOoIYcnUwubdQ.Z4ByRDdE1AYwFowZPD9a4.tjt7a',NULL,NULL),(17,'0011783174556501','dkssud@gktp.dy','김씨','$2a$10$LNA0J/MGiwKPVDtcCZJDxetX57Vhzf..8RUCSjFXigolVKUUSbV36','https://arbaguette.s3.ap-northeast-2.amazonaws.com/202410102102402724647206846754','010-9999-8888','c9a607c3-23d4-4ced-98e0-a6954d4a5393',NULL,NULL,'UNREGISTERED','$2a$10$mjHwvrnsxexkozs5Kc2qku01KULr9xLP5h4/kzyQE4rRIhD15C4fy',NULL,'ExponentPushToken[1gyHkBA3OR1o7BLrSz4R62]');
/*!40000 ALTER TABLE `crew` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 21:08:11
